
# Dependencies

sudo apt-get install python-requests

SPI must be enabled, in /boot/config.txt look for and uncomment "dtparam=spi=on"
